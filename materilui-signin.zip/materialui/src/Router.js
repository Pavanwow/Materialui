
import React, { Component } from "react";
import { Route, BrowserRouter, Redirect } from "react-router-dom";
import SignIn from "./SignIn";
import SignUp from "./SignUp";
import NevBar from "./NevBar";

class Router extends Component {
  render() {
    return (
      <BrowserRouter>
      <NevBar />
      <Route path="/SignIn" component={SignIn} />
      <Route path="/SignUp" component={SignUp} />
      
      </BrowserRouter>
    );
  }
}

export default Router;
